# Definerer en funktion kaldet 'print_besked'
def print_besked():
    # Denne linje printer en besked til konsollen
    print("hej fra importeret funktion")