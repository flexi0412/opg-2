# Importerer funktionen 'print_besked' fra filen 'print_besked'
from print_hej import print_besked

# Kald funktionen for at vise beskeden på konsollen
print_besked()